async function fetchData(url, colorBoxId) {
    const colorBox = document.getElementById(colorBoxId);
    if (colorBox) {
        colorBox.style.backgroundColor = 'black';

        try {
            const response = await fetch(url);
            const data = await response.json();
            const status = data[0].previous_process_plan_result;

            switch (status) {
                case 'PASSED':
                    colorBox.style.backgroundColor = 'green';
                    break;
                case 'FAILED':
                    colorBox.style.backgroundColor = 'red';
                    break;
                case 'ABORTED':
                    colorBox.style.backgroundColor = 'blue';
                    break;
                case '':
                    colorBox.style.backgroundColor = 'orange';
                    break;
                default:
                    colorBox.style.backgroundColor = 'black';
                    break;
            }
        } catch (error) {
            console.error('Error fetching data:', error);
            colorBox.style.backgroundColor = 'black';
        }
    } else {
        console.error(`Element with id ${colorBoxId} not found.`);
    }
}

function startMonitoring() {
    const urls = [
        { url: 'http://172.31.6.1:8090/get_all_process_stations_ui/', id: 'colorBox1' },
        { url: 'http://172.31.6.2:8090/get_all_process_stations_ui/', id: 'colorBox2' },
        { url: 'http://172.31.6.3:8090/get_all_process_stations_ui/', id: 'colorBox3' },
        { url: 'http://172.31.6.4:8090/get_all_process_stations_ui/', id: 'colorBox4' },
        { url: 'http://172.31.6.5:8090/get_all_process_stations_ui/', id: 'colorBox5' },
        { url: 'http://172.31.6.6:8090/get_all_process_stations_ui/', id: 'colorBox6' },
        { url: 'http://172.31.6.7:8090/get_all_process_stations_ui/', id: 'colorBox7' },
        { url: 'http://172.31.6.8:8090/get_all_process_stations_ui/', id: 'colorBox8' }, 
        { url: 'http://172.31.6.9:8090/get_all_process_stations_ui/', id: 'colorBox9' },
        { url: 'http://172.31.6.10:8090/get_all_process_stations_ui/', id: 'colorBox10' },
        { url: 'http://172.31.6.11:8090/get_all_process_stations_ui/', id: 'colorBox11' },
        { url: 'http://172.31.6.12:8090/get_all_process_stations_ui/', id: 'colorBox12' },
        { url: 'http://172.31.6.13:8090/get_all_process_stations_ui/', id: 'colorBox13' },
        { url: 'http://172.31.6.14:8090/get_all_process_stations_ui/', id: 'colorBox14' },
        { url: 'http://172.31.6.15:8090/get_all_process_stations_ui/', id: 'colorBox15' },
        { url: 'http://172.31.6.16:8090/get_all_process_stations_ui/', id: 'colorBox16' },
        { url: 'http://172.31.6.17:8090/get_all_process_stations_ui/', id: 'colorBox17' },
        { url: 'http://172.31.6.18:8090/get_all_process_stations_ui/', id: 'colorBox18' },
        { url: 'http://172.31.6.19:8090/get_all_process_stations_ui/', id: 'colorBox19' },
        { url: 'http://172.31.6.20:8090/get_all_process_stations_ui/', id: 'colorBox20' },
        { url: 'http://172.31.6.21:8090/get_all_process_stations_ui/', id: 'colorBox21' },
        { url: 'http://172.31.6.22:8090/get_all_process_stations_ui/', id: 'colorBox22' },
        { url: 'http://172.31.6.23:8090/get_all_process_stations_ui/', id: 'colorBox23' },
        { url: 'http://172.31.6.24:8090/get_all_process_stations_ui/', id: 'colorBox24' },
        { url: 'http://172.31.6.25:8090/get_all_process_stations_ui/', id: 'colorBox25' },
        { url: 'http://172.31.6.26:8090/get_all_process_stations_ui/', id: 'colorBox26' },
        { url: 'http://172.31.6.27:8090/get_all_process_stations_ui/', id: 'colorBox27' },
        { url: 'http://172.31.6.28:8090/get_all_process_stations_ui/', id: 'colorBox28' },
        { url: 'http://172.31.6.29:8090/get_all_process_stations_ui/', id: 'colorBox29' },
        // Finish Palomar
        { url: 'http://172.31.6.52:8090/get_all_process_stations_ui/', id: 'colorBox30' },
        { url: 'http://172.31.6.53:8090/get_all_process_stations_ui/', id: 'colorBox31' },
        { url: 'http://172.31.6.54:8090/get_all_process_stations_ui/', id: 'colorBox32' },
        { url: 'http://172.31.6.51:8090/get_all_process_stations_ui/', id: 'colorBox33' },
        { url: 'http://172.31.6.55:8090/get_all_process_stations_ui/', id: 'colorBox34' },
        { url: 'http://172.31.6.64:8090/get_all_process_stations_ui/', id: 'colorBox35' },
        { url: 'http://172.31.6.77:8090/get_all_process_stations_ui/', id: 'colorBox36' },
        { url: 'http://172.31.6.78:8090/get_all_process_stations_ui/', id: 'colorBox37' },
        { url: 'http://172.31.6.65:8090/get_all_process_stations_ui/', id: 'colorBox38' },
        { url: 'http://172.31.6.62:8090/get_all_process_stations_ui/', id: 'colorBox39' },
        { url: 'http://172.31.6.99:8090/get_all_process_stations_ui/', id: 'colorBox40' },
        { url: 'http://172.31.6.72:8090/get_all_process_stations_ui/', id: 'colorBox41' },
        { url: 'http://172.31.6.70:8090/get_all_process_stations_ui/', id: 'colorBox42' },
        { url: 'http://172.31.6.56:8090/get_all_process_stations_ui/', id: 'colorBox43' },
        { url: 'http://172.31.6.57:8090/get_all_process_stations_ui/', id: 'colorBox44' },
        { url: 'http://172.31.6.58:8090/get_all_process_stations_ui/', id: 'colorBox45' },
        { url: 'http://172.31.6.59:8090/get_all_process_stations_ui/', id: 'colorBox46' },
        { url: 'http://172.31.6.60:8090/get_all_process_stations_ui/', id: 'colorBox47' },
        { url: 'http://172.31.6.63:8090/get_all_process_stations_ui/', id: 'colorBox48' },
        { url: 'http://172.31.6.67:8090/get_all_process_stations_ui/', id: 'colorBox49' },
        { url: 'http://172.31.6.68:8090/get_all_process_stations_ui/', id: 'colorBox50' },
        { url: 'http://172.31.6.73:8090/get_all_process_stations_ui/', id: 'colorBox51' },
        { url: 'http://172.31.6.69:8090/get_all_process_stations_ui/', id: 'colorBox52' },
        { url: 'http://172.31.6.75:8090/get_all_process_stations_ui/', id: 'colorBox53' },
        { url: 'http://172.31.6.66:8090/get_all_process_stations_ui/', id: 'colorBox54' },
        { url: 'http://172.31.6.71:8090/get_all_process_stations_ui/', id: 'colorBox55' },
        { url: 'http://172.31.6.74:8090/get_all_process_stations_ui/', id: 'colorBox56' },
        { url: 'http://172.31.6.76:8090/get_all_process_stations_ui/', id: 'colorBox57' },
        // Finish Mako Shark
        { url: 'http://172.31.19.1:8090/get_all_process_stations_ui/', id: 'colorBox58' },
        { url: 'http://172.31.19.2:8090/get_all_process_stations_ui/', id: 'colorBox59' },
        { url: 'http://172.31.19.3:8090/get_all_process_stations_ui/', id: 'colorBox60' },
        { url: 'http://172.31.18.251:8090/get_all_process_stations_ui/', id: 'colorBox61' },
        { url: 'http://172.31.19.6:8000/get_all_process_stations_ui/', id: 'colorBox62' },
        { url: 'http://172.31.16.4:8000/get_all_process_stations_ui/', id: 'colorBox63' },
        { url: 'http://172.31.16.6:8000/get_all_process_stations_ui/', id: 'colorBox64' },
        { url: 'http://172.31.16.7:8090/get_all_process_stations_ui/', id: 'colorBox65' },
        { url: 'http://172.31.16.8:8000/get_all_process_stations_ui/', id: 'colorBox66' },
        { url: 'http://172.31.17.2:8000/get_all_process_stations_ui/', id: 'colorBox67' },
        { url: 'http://172.31.17.250:8000/get_all_process_stations_ui/', id: 'colorBox68' },
        { url: 'http://172.31.17.251:8000/get_all_process_stations_ui/', id: 'colorBox69' },
        { url: 'http://172.31.17.252:8000/get_all_process_stations_ui/', id: 'colorBox70' },
        { url: 'http://172.31.17.253:8000/get_all_process_stations_ui/', id: 'colorBox71' },
        { url: 'http://172.31.17.254:8000/get_all_process_stations_ui/', id: 'colorBox72' },
        { url: 'http://172.31.18.7:8000/get_all_process_stations_ui/', id: 'colorBox73' },
        { url: 'http://172.31.18.8:8000/get_all_process_stations_ui/', id: 'colorBox74' },
        { url: 'http://172.31.18.9:8000/get_all_process_stations_ui/', id: 'colorBox75' },
        { url: 'http://172.31.18.250:8000/get_all_process_stations_ui/', id: 'colorBox76' },
        // Finish Teygeta
        { url: 'http://172.31.13.1:8090/get_all_process_stations_ui/', id: 'colorBox77' },
        { url: 'http://172.31.13.4:8090/get_all_process_stations_ui/', id: 'colorBox78' },
        { url: 'http://172.31.14.6:8090/get_all_process_stations_ui/', id: 'colorBox79' },
        { url: 'http://172.31.14.9:8090/get_all_process_stations_ui/', id: 'colorBox80' },
        { url: 'http://172.31.15.7:8090/get_all_process_stations_ui/', id: 'colorBox81' },
        { url: 'http://172.31.13.5:8090/get_all_process_stations_ui/', id: 'colorBox82' },
        { url: 'http://172.31.15.5:8090/get_all_process_stations_ui/', id: 'colorBox83' },
        { url: 'http://172.31.13.7:8090/get_all_process_stations_ui/', id: 'colorBox84' },
        { url: 'http://172.31.13.250:8090/get_all_process_stations_ui/', id: 'colorBox85' },
        { url: 'http://172.31.13.251:8090/get_all_process_stations_ui/', id: 'colorBox86' },
        { url: 'http://172.31.13.252:8090/get_all_process_stations_ui/', id: 'colorBox87' },
        { url: 'http://172.31.13.253:8090/get_all_process_stations_ui/', id: 'colorBox88' },
        { url: 'http://172.31.13.254:8000/get_all_process_stations_ui/', id: 'colorBox89' },
        { url: 'http://172.31.14.1:8090/get_all_process_stations_ui/', id: 'colorBox90' },
        { url: 'http://172.31.14.2:8090/get_all_process_stations_ui/', id: 'colorBox91' },
        { url: 'http://172.31.14.3:8090/get_all_process_stations_ui/', id: 'colorBox92' },
        { url: 'http://172.31.14.4:8000/get_all_process_stations_ui/', id: 'colorBox93' },
        { url: 'http://172.31.14.5:8090/get_all_process_stations_ui/', id: 'colorBox94' },
        { url: 'http://172.31.14.250:8090/get_all_process_stations_ui/', id: 'colorBox95' },
        { url: 'http://172.31.14.252:8090/get_all_process_stations_ui/', id: 'colorBox96' },
        { url: 'http://172.31.14.253:8090/get_all_process_stations_ui/', id: 'colorBox97' },
        { url: 'http://172.31.14.254:8090/get_all_process_stations_ui/', id: 'colorBox98' }
        // Finish Brixia
    ];
    setInterval(() => {
        urls.forEach(({ url, id }) => fetchData(url, id));
    }, 10000);
}

window.onload = startMonitoring;
